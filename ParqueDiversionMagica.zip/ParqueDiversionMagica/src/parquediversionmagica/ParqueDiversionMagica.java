/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package parquediversionmagica;

public class ParqueDiversionMagica {

    public static void main(String[] args) {

        // Crear 3 juegos
        Juego juego1 = new Juego("Montaña Rusa", 12, 5, 1.40);
        Juego juego2 = new Juego("Carrusel", 5, 8, 1.00);
        Juego juego3 = new Juego("Autos Chocadores", 8, 6, 1.20);

        // Datos 
        int edadNiño = 10;
        double alturaNiño = 1.35;

        System.out.println("=== PARQUE DIVERSION MAGICA ===");
        System.out.println("Edad del niño: " + edadNiño);
        System.out.println("Altura del niño: " + alturaNiño + " metros");
        System.out.println();

        // Juego 1
        juego1.mostrarInfo();

        if (juego1.puedeSubir(edadNiño, alturaNiño)) {
            System.out.println("Puede subir.");
        } else {
            System.out.println("No puede subir.");
        }

        System.out.println("----------------------");

        // Juego 2
        juego2.mostrarInfo();

        if (juego2.puedeSubir(edadNiño, alturaNiño)) {
            System.out.println("Puede subir.");
        } else {
            System.out.println("No puede subir.");
        }

        System.out.println("----------------------");

        // Juego 3
        juego3.mostrarInfo();

        if (juego3.puedeSubir(edadNiño, alturaNiño)) {
            System.out.println("Puede subir.");
        } else {
            System.out.println("No puede subir.");
        }
    }
}
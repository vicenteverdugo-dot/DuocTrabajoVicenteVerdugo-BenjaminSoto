package parquediversionmagica;

public class Juego {

    private String nombre;
    private int edadMinima;
    private int duracion;
    private double alturaMinima;

    public Juego(String nombre, int edadMinima, int duracion, double alturaMinima) {
        this.nombre = nombre;
        this.edadMinima = edadMinima;
        this.duracion = duracion;
        this.alturaMinima = alturaMinima;
    }

    public void mostrarInfo() {
        System.out.println("Juego: " + nombre);
        System.out.println("Edad minima: " + edadMinima + " años");
        System.out.println("Duracion: " + duracion + " minutos");
        System.out.println("Altura minima: " + alturaMinima + " metros");
    }

    public boolean puedeSubir(int edad, double altura) {
        return edad >= edadMinima && altura >= alturaMinima;
    }
}   
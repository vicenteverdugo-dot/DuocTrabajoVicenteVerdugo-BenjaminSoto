/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package playlist;

/**
 *
 * @author AL-Alumno
 */
public class Cancion {
    private String titulo;
    private String artista;
    private int duracionSeg;
 
    // Constructor vacio
    public Cancion() {
        titulo = "Sin titulo";
        artista = "Desconocido";
        duracionSeg = 0;
    }
 
    // Constructor con parametros
    public Cancion(String t, String a, int d) {
        titulo = t;
        artista = a;
        duracionSeg = d;
    }
 
    // Getters y setters
    public String getTitulo() {
        return titulo;
    }
 
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }
 
    public String getArtista() {
        return artista;
    }
 
    public void setArtista(String artista) {
        this.artista = artista;
    }
 
    public int getDuracionSeg() {
        return duracionSeg;
    }
 
    public void setDuracionSeg(int duracionSeg) {
        this.duracionSeg = duracionSeg;
    }
 
    // true si dura mas de 240 segundos
    public boolean esLarga() {
        return duracionSeg > 240;
    }
 
    // 185 -> 3:05
    public String duracionFormato() {
        int minutos = duracionSeg / 60;
        int segundos = duracionSeg % 60;
        if (segundos < 10) {
            return minutos + ":0" + segundos;
        }
        return minutos + ":" + segundos;
    }
 
    public void mostrar() {
        System.out.println(titulo + " - " + artista);
        System.out.println("Duracion: " + duracionFormato());
        if (esLarga()) {
            System.out.println("Es una cancion larga");
        } else {
            System.out.println("No es una cancion larga");
        }
        System.out.println();
    }
}

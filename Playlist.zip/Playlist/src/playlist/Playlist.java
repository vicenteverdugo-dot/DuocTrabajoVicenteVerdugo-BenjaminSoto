/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package playlist;

/**
 *
 * @author AL-Alumno
 */
public class Playlist {

    public static void main(String[] args) {
 
        Cancion c1 = new Cancion("Blinding Lights", "The Weeknd", 200);
        Cancion c2 = new Cancion("Bohemian Rhapsody", "Queen", 355);
        Cancion c3 = new Cancion("Shape of You", "Ed Sheeran", 234);
 
        System.out.println("===== TOP 3 CANCIONES =====");
        System.out.println();
 
        System.out.println("#1");
        c1.mostrar();
        System.out.println("#2");
        c2.mostrar();
        System.out.println("#3");
        c3.mostrar();
 
        // Cambiamos la duracion con el setter
        System.out.println("===== CAMBIO DE DURACION =====");
        System.out.println();
        c1.setDuracionSeg(260);
 
        System.out.println("Despues de cambiar la duracion de la #1:");
        c1.mostrar();
    }
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mascotavirual;

/**
 *
 * @author AL-Alumno
 */
public class Mascota {
    private String nombre;
    private int energia;
    private int hambre;

    public Mascota(String nombre) {
        this.nombre = nombre;
        this.energia = 100;
        this.hambre = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEnergia() {
        return energia;
    }

    public void setEnergia(int energia) {
        this.energia = energia;
    }

    public int getHambre() {
        return hambre;
    }

    public void setHambre(int hambre) {
        this.hambre = hambre;
    }
    
    public void comer(){
        if (hambre < 30) {
            setHambre(0);
            System.out.println("Tu mascota ha comido de forma riguroza");
        } else {
            hambre = hambre - 30;
            System.out.println("Tu mascota ha comido de forma riguroza");
        }
    }
    
    public void jugar(){
        if (energia < 20){
            setEnergia(0);
            hambre = hambre + 15;
            System.out.println("Has jugado con tu linda mascota :3");
        } else {
            energia = energia - 20;
            hambre = hambre + 15;
            System.out.println("Has jugado con tu linda mascota :3");
        }
    }
    
    public void dormir(){
        if (energia <= 100){
            System.out.println("Tu mascota no esta cansada. -v-");
        } else {
            setEnergia(100);
            System.out.println("Tu mascota se ha recuperado por completo :o");
        }
    }
    
    public boolean estaFeliz(){
        if (energia > 50 && hambre < 50){
            return true;
        } else {
            return false;
        }
    }
    
    public void mostrarEstado(){
        if(estaFeliz()){
            System.out.println("Tu mascota esta super feliz jeje");
        } else {
            System.out.println("Tu mascota esta tite (muy mal)");
        }
    }
}

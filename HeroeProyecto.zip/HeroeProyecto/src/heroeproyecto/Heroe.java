/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package heroeproyecto;

public class Heroe {

    private String nombre;
    private int vida;
    private int ataque;

    public Heroe(String nombre, int vida, int ataque) {
        this.nombre = nombre;
        this.vida = vida;
        this.ataque = ataque;
    }

    public void atacar(Heroe rival) {
        rival.setVida(rival.getVida() - ataque);

        if (rival.getVida() < 0) {
            rival.setVida(0);
        }

        System.out.println(nombre + " ataca a " + rival.getNombre()
                + " y le quita " + ataque + " de vida.");
    }

    public boolean estaVivo() {
        return vida > 0;
    }

    public String getNombre() {
        return nombre;
    }

    public int getVida() {
        return vida;
    }

    public int getAtaque() {
        return ataque;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public void setAtaque(int ataque) {
        this.ataque = ataque;
    }
}
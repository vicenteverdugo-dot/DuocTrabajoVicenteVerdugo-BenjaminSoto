/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package heroeproyecto;

public class HeroeProyecto {

    public static void main(String[] args) {

        Heroe heroe1 = new Heroe("Valkiria", 100, 30);
        Heroe heroe2 = new Heroe("Golem", 130, 22);

        while (heroe1.estaVivo() && heroe2.estaVivo()) {

            heroe1.atacar(heroe2);

            if (heroe2.estaVivo()) {
                heroe2.atacar(heroe1);
            }

            System.out.println("Valkiria: " + heroe1.getVida() + " HP");
            System.out.println("Golem: " + heroe2.getVida() + " HP");
            System.out.println("----------------");
        }

        if (heroe1.estaVivo()) {
            System.out.println("Ganador: " + heroe1.getNombre());
        } else {
            System.out.println("Ganador: " + heroe2.getNombre());
        }
    }
}
